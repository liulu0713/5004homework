package student;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Represents a salaried employee. */
public class SalaryEmployee extends AbstractEmployee {

    /**
     * Constructs a salaried employee.
     *
     * @param name employee name
     * @param id employee id
     * @param annualSalary annual salary
     * @param pretaxDeductions pretax deductions
     * @param ytdEarnings year-to-date earnings
     * @param ytdTaxesPaid year-to-date taxes paid
     */
    public SalaryEmployee(String name, String id, double annualSalary,
                          double ytdEarnings, double ytdTaxesPaid, double pretaxDeductions) {

        super(name, id, annualSalary, ytdEarnings, ytdTaxesPaid, pretaxDeductions);
    }

    /** Calculates gross pay for salaried employee (annualSalary / 24). */
    @Override
    protected BigDecimal calculateGrossPay(double hoursWorked) {
        return BigDecimal.valueOf(getPayRate())
                .divide(BigDecimal.valueOf(24), 2, RoundingMode.HALF_UP);
    }

    /** Returns employee type. */
    @Override
    public String getEmployeeType() {
        return "SALARY";
    }

}
