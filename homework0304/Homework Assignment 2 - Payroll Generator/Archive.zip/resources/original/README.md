#Resources -> Originals

These files are originals. Since your program will overwrite employees.csv, we wanted
to provide copies of the original files we gave. There is
also a solution file here that you can use to check your answers.

You should create ADDITIONAL test files! Don't just rely on these ones!