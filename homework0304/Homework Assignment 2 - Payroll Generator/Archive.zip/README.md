Name:Lu Liu
https://github.com/liulu0713/5004homework

How many hours did it take you to complete this assignment (estimate)?

40 hours

Did you collaborate with any other students/TAs/Professors? If so, tell us who and in what
capacity.
students
20% , expecially for debugging

* one per row, add more if needed
  
Did you use any external resources (you do not have to cite in class material)? (Cite them below)
Yes.
https://docs.oracle.com/javase/tutorial/collections/interfaces/index.html
youtube java videos
ChatGPT
* one row per resource


(Optional) What was your favorite part of the assignment?
the collection of interfacec 
(Optional) How would you improve the assignment?
May be pay less attention on rounding up numbers
---
