Name:

How many hours did it take you to complete this assignment (estimate)?

Did you collaborate with any other students/TAs/Professors? If so, tell us who and in what
capacity.

* one per row, add more if needed
  
Did you use any external resources (you do not have to cite in class material)? (Cite them below)

* one row per resource


(Optional) What was your favorite part of the assignment?

(Optional) How would you improve the assignment?

---
