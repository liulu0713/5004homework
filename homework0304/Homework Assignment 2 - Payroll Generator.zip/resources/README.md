# Resources

Resources are files the program uses to read and write data. The program will
overwrite `employees.csv`, so originals are in the originals folder.

Make sure you write your own test files! Don't just rely on these ones! They 
are only one 'happy path' type input. 

In addition to unit testing, it is often good to generate files to test against.